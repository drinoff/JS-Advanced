function getArticleGenerator(articles) {
    // TODO
}
