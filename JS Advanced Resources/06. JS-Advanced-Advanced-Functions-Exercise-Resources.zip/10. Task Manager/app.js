function solve() {
    console.log("//TODO")
}